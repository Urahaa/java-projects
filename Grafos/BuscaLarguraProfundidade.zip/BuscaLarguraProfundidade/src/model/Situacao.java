package model;

public enum Situacao {
    BRANCO,
    CINZA,
    PRETO,
}
